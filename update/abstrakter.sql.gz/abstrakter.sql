-- Adminer 4.0.3 MySQL dump

SET NAMES utf8;
SET foreign_key_checks = 0;
SET time_zone = '+01:00';
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DROP TABLE IF EXISTS `kongressdata`;
CREATE TABLE `kongressdata` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `congress_titel` longtext COLLATE utf8_slovak_ci NOT NULL,
  `congress_subtitel` longtext COLLATE utf8_slovak_ci NOT NULL,
  `congress_url` text COLLATE utf8_slovak_ci,
  `congress_venue` longtext COLLATE utf8_slovak_ci NOT NULL,
  `congress_regfrom` date NOT NULL,
  `congress_reguntil` date NOT NULL,
  `congress_from` date NOT NULL,
  `congress_until` date NOT NULL,
  `congress_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`),
  UNIQUE KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_slovak_ci;

INSERT INTO `kongressdata` (`item_id`, `congress_titel`, `congress_subtitel`, `congress_url`, `congress_venue`, `congress_regfrom`, `congress_reguntil`, `congress_from`, `congress_until`, `congress_created`) VALUES
(1,	'xx',	'xx',	'xx',	'xx',	'2014-02-11',	'2014-02-17',	'2014-06-19',	'2014-06-21',	'2014-02-11 09:48:37'),
(11,	'trauma',	'v detskom veku',	'xx',	'xx',	'2014-03-11',	'2014-04-20',	'2014-06-19',	'2014-06-21',	'2014-02-11 10:03:38');

DROP TABLE IF EXISTS `registration`;
CREATE TABLE `registration` (
  `item_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) NOT NULL,
  `congress_id` bigint(20) NOT NULL,
  `participation` enum('aktiv','pasiv','visit') CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT 'pasiv',
  `abstract_titul` longtext COLLATE utf8_slovak_ci,
  `abstract_main_autor` text COLLATE utf8_slovak_ci,
  `abstract_autori` longtext COLLATE utf8_slovak_ci,
  `abstract_adresy` longtext COLLATE utf8_slovak_ci,
  `abstract_text` longtext COLLATE utf8_slovak_ci,
  `abstract_created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_slovak_ci;

INSERT INTO `registration` (`item_id`, `user_id`, `congress_id`, `participation`, `abstract_titul`, `abstract_main_autor`, `abstract_autori`, `abstract_adresy`, `abstract_text`, `abstract_created`) VALUES
(2,	10,	11,	'aktiv',	'xxx',	'ccc',	'',	'ccccccc',	'ccc',	'2014-02-11 14:24:05'),
(3,	10,	11,	'aktiv',	'xxx',	'ccc',	'',	'ccccccc',	'ccc',	'2014-02-11 14:24:38');

DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `email` text CHARACTER SET ascii NOT NULL,
  `password` text CHARACTER SET ascii NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `email` (`email`(100))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_slovak_ci;

INSERT INTO `users` (`id`, `email`, `password`, `timestamp`) VALUES
(10,	'bduchaj@gmail.com',	'4124bc0a9335c27f086f24ba207a4912',	'2014-02-09 08:47:48'),
(23,	'xx@xx.sk',	'4124bc0a9335c27f086f24ba207a4912',	'2014-02-10 20:54:19');

DROP TABLE IF EXISTS `usersdata`;
CREATE TABLE `usersdata` (
  `user_id` bigint(20) NOT NULL,
  `titul_pred` text COLLATE utf8_slovak_ci,
  `meno` text COLLATE utf8_slovak_ci NOT NULL,
  `priezvisko` text COLLATE utf8_slovak_ci NOT NULL,
  `titul_za` text COLLATE utf8_slovak_ci,
  `adresa` longtext COLLATE utf8_slovak_ci,
  `contact_email` text COLLATE utf8_slovak_ci NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY `user_id` (`user_id`),
  CONSTRAINT `usersdata_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_slovak_ci;

INSERT INTO `usersdata` (`user_id`, `titul_pred`, `meno`, `priezvisko`, `titul_za`, `adresa`, `contact_email`, `created`) VALUES
(10,	'MUDr.',	'Boris',	'Duchaj',	'PhD.,',	'Klinika detskej chirugie LF UK a DFNsP\r\nLimbovÃ¡ 1\r\n833 40 Bratislava\r\n\r\nmaleveci su velke veci a naco su nam a preco je toto na dve veci\r\n\r\npreco nefunguje sesseion\r\n\r\n',	'bduchaj@gmail.com',	'2014-02-11 06:43:30'),
(23,	'toto je husrea',	'lkjfkdjfdlk',	'nlakjdslk',	'lskjdlkjdlk',	'lsdlakjdslkdj',	'xx@xx.sk',	'2014-02-10 20:54:40');

-- 2014-02-11 15:27:38
